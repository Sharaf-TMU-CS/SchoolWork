The program works fully, every aspect has been completed.
I did not attempt the bonus.